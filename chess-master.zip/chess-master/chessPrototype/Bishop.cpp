﻿#include "Bishop.h"

#define myabs(x) ((x) < 0 ? -(x) : (x))

//비숍 이동 코드(대각선 이동)
bool Bishop::Move(int x0, int y0, int x1, int y1)
{
	if (myabs(x0 - x1) == myabs(y0 - y1)) //이동하고자 하는 거리가 가로=세로(<=> 대각선) 이면 이동
		return Piece::Move(x0, y0, x1, y1);
	return false;
}

Bishop::Bishop(unsigned int player)
: Piece(Piece::Bishop, player)
{}
