﻿/**
* @file     Knight.cpp
* @author   장하림
* @date     21/05/21
*/
#include "Knight.h"
#include <iostream>


Knight::Knight(int player)
	:Piece(Piece::Knight, player)
{}
//Knight의 위치를 초기하는 생성자, Piece::Knight=2번


/**
* @brief    Move
* @detail   Knight의 이동 함수
*           조건1-1[(x0 - x1) == 2 || (x0 - x1) == -2] : Knight이 현재 있는 위치에서의 가로축 2,-2로 이동하고
*           조건1-2[(y0 - y1) == 1 || (y0 - y1) == -1] : Knight이 현재 있는 위치에서의 세로축 1,-1로 이동
*			조건2-1[(x0 - x1) == 1 || (x0 - x1) == -1] : Knight이 현재 있는 위치에서의 가로축 1,-1로 이동하고
*           조건2-2[(y0 - y1) == 2 || (y0 - y1) == -2] : Knight이 현재 있는 위치에서의 세로축 2,-2로 이동
* @param    x0, y0 : 기존 말의 위치
*           x1, y1 : 이동할 말의 위치
*/
bool Knight::Move(int x0, int y0, int x1, int y1)
{
	if ((x0 - x1) == 2 || (x0 - x1) == -2) {
		if ((y0 - y1) == 1 || (y0 - y1) == -1)	{
			return Piece::Move(x0, y0, x1, y1);
		}
	}
	else if ((x0 - x1) == 1 || (x0 - x1) == -1) {
		if ((y0 - y1) == 2 || (y0 - y1) == -2)	{	
			return Piece::Move(x0, y0, x1, y1);			
		}
	}
	return false;
}
