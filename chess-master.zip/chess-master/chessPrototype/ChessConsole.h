﻿#pragma once

#include "ChessBoard.h"
#include "Piece.h"
#include "ChessGraphics.h"

class ChessConsole
{
private:
	bool SYSTEM = true;
	ChessBoard board;
	ChessGraphics graphics;
	unsigned int player = Piece::Black;
private:
	ChessConsole(ChessConsole& program);

	void Executecommand(void);
public:
	ChessConsole(void);
	int Run(void);
};
