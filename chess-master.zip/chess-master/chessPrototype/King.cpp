﻿/**
* @file     King.cpp
* @author   장하림
* @date     21/05/21
*/
#include "King.h"

King::King(int player)
	:Piece(Piece::King, player)
{}

/**
* @brief    Move
* @detail   King의 이동 함수
*           조건1[x1 == x0 - 1 || x1 == x0 + 1 || x1 == x0] : King이 현재 있는 위치에서의 가로축 +1,0,-1로 이동
*           조건2[y1 == y0 - 1 || y1 == y0 + 1 || y1 == y0] : King이 현재 있는 위치에서의 세로축 +1,0,-1로 이동
* @param    x0, y0 : 기존 말의 위치
*           x1, y1 : 이동할 말의 위치
*/
bool King::Move(int x0, int y0, int x1, int y1)
{
	if (x1 == x0 - 1 || x1 == x0 + 1 || x1 == x0)
		if (y1 == y0 - 1 || y1 == y0 + 1 || y1 == y0)
			return Piece::Move(x0, y0, x1, y1);
	return false;
}
