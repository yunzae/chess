﻿/**
* @file     King.h
* @author   장하림
* @date     21/05/21
* @brief    Move : 킹이 이동할 수 있는 거리이고 또 그것이 체스판을 벗어나지 않는지 확인
*/
#pragma once

#include "Piece.h"

class King : public Piece
{
private:
 	bool first = true;
public:
	King(int player);
	bool Move(int x0, int y0, int x1, int y1);
	
	friend class ChessBoard;
};
