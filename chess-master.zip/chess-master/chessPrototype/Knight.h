﻿/**
* @file     Knight.h
* @author   장하림
* @date     21/05/21
* @brief    Move : 나이트가 이동할 수 있는 거리이고 또 그것이 체스판을 벗어나지 않는지 확인
*/
#pragma once

#include "Piece.h"

class Knight :public Piece
{
public:
	Knight(int player);
	bool Move(int x0, int y0, int x1, int y1);
};
