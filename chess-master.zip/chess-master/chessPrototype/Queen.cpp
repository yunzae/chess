﻿#include "Queen.h"
// 절댓값 함수 정의
#define myabs(x) ((x) < 0 ? -(x) : (x))

bool Queen::Move(int x0, int y0, int x1, int y1)
{
	if (x0 == x1) // 직선 이동(x좌표가 같은 경우)
		return Piece::Move(x0, y0, x1, y1);
	else if (y0 == y1) // 직선 이동(y좌표가 같은 경우)
		return Piece::Move(x0, y0, x1, y1);
	else if(myabs(x0 - x1) == myabs(y0 - y1)) // 대각선 이동
		return Piece::Move(x0, y0, x1, y1);

	return false;
}

Queen::Queen(int player)
: Piece(Piece::Queen, player) 
{}
