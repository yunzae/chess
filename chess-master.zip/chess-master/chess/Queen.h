/**
* @file     Queen.h
* @author   김나영
* @date     21/05/28
* @brief    Queen 말의 기본 클래스
*/
#pragma once

#include "Piece.h"

class Queen : public Piece
{
public:
	Queen(int player);
	bool Move(int x0, int y0, int x1, int y1) const;
};
