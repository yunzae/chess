#pragma once

#include "Piece.h"

class Knight :public Piece
{
public:
	Knight(int player);
	bool Move(int x0, int y0, int x1, int y1);
};
