/**
* @file     Queen.cpp
* @author   김나영
* @date     21/05/28
*/
#include "Queen.h"

#define myabs(x) ((x) < 0 ? -(x) : (x))

/**
* @brief    Move function
* @detail   말의 위치정보(기존위치+이동할위치)를 입력받아 각 조건에 부합하게 말을 이동
*           조건1[x0 == x1] : 기존 위치의 x 값과 이동할 위치의 x 값이 일치 => x축으로 직선 이동
*           조건2[y0 == y1] : 기존 위치의 y 값과 이동할 위치의 y 값이 일치 => y축으로 직선 이동
*           조건3[myabs(x0 - x1) == myabs(y0 - y1)] : 기존/이동할 위치의 x값의 차와 y값의 차가 일치 => 대각선으로 이동
* @param    x0, y0 : 기존 말의 위치
*           x1, y1 : 이동할 말의 위치
*/

bool Queen::Move(int x0, int y0, int x1, int y1)
{
	if (x0 == x1) //조건1
		return Piece::Move(x0, y0, x1, y1);
	else if (y0 == y1) //조건2
		return Piece::Move(x0, y0, x1, y1);
	else if(myabs(x0 - x1) == myabs(y0 - y1)) //조건3
		return Piece::Move(x0, y0, x1, y1);
