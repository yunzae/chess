/**
* @file     Bishop.cpp
* @author   김나영
* @date     21/05/28
*/
#include "Bishop.h"

#define myabs(x) ((x) < 0 ? -(x) : (x))

/**
* @brief    Move function
* @detail   말의 위치정보(기존위치+이동할위치)를 입력받아 조건에 부합하면 말을 이동
*           조건[myabs(x0 - x1) == myabs(y0 - y1)] : 기존/이동할 위치의 x값의 차와 y값의 차가 같으면 대각선으로 이동 
* @param    x0, y0 : 기존 말의 위치
*           x1, y1 : 이동할 말의 위치
*/

bool Bishop::Move(int x0, int y0, int x1, int y1)
{
	if (myabs(x0 - x1) == myabs(y0 - y1)) 
		return Piece::Move(x0, y0, x1, y1);
	return false;
}

Bishop::Bishop(unsigned int player)
: Piece(Piece::Bishop, player)
{}
