/**
* @file     Knight.cpp
* @author   장하림
* @date     21/05/18
*/
#include "Knight.h"
#include <iostream>

/**
* @brief    Move
* @detail   Knight의 이동 함수
*           조건1[x0>=x1-1,x0<=x1+1] : King이 현재 있는 위치에서의 가로축 +1,0,-1로 이동
*           조건2[y0>=x1-1,y0<=y1+1] : King이 현재 있는 위치에서의 세로축 +1,0,-1로 이동
* @param    x0, y0 : 기존 말의 위치
*           x1, y1 : 이동할 말의 위치
*/

Knight::Knight(int player)
:Piece(Piece::Knight, player)
{}
//Knight의 위치를 초기하는 생성자, Piece::Knight=2번

bool Knight::Move(int x0, int y0, int x1, int y1)
{
	if ((x0 - x1) == 2 || (x0 - x1) == -2) {
		if ((y0 - y1) == 1 || (y0 - y1) == -1)	{
			return Piece::Move(x0, y0, x1, y1);
		}
	}
	else if ((x0 - x1) == 1 || (x0 - x1) == -1) {
		if ((y0 - y1) == 2 || (y0 - y1) == -2)	{	
			return Piece::Move(x0, y0, x1, y1);			
		}
	}
	return false;
}
