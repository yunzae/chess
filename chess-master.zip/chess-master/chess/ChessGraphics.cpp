/**
* @file		ChessGraphics.cpp
* @author	이영한,김나영
* @date		21/05/21
*/
#include <iostream>
#include <Windows.h>
#include "Piece.h"
#include "ChessBoard.h" 
#include "ChessGraphics.h"

ChessGraphics::ChessGraphics(const ChessBoard* pBoard)
	: pBoard(pBoard)
{}

/**
* @brief	체스판 틀(구조) 출력
* @detail	콘솔창에 다음과 같이 출력
*		8
*		7
*		6
*		5
*		4
*		3
*		2
*		1
*		 A B C D E F G H
*/
void ChessGraphics::PrintBoard(void) const
{
	const char indexBottom[] = "ABCDEFGH";
	const Piece* pPiece = 0;

	for (int i = 0; i <= 8; i++)
	{
		for (int j = 0; j <= 8; j++)
		{
			/* 1. 체스판 테두리(체스판 최하단)에 ABCDEFGH 인덱스 출력 */
			if (i == 8)
			{
				if (j == 0)
					std::cout << "  ";
				else
				{
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY);
					std::cout << indexBottom[j - 1] << " ";
				}
				continue;
			}
			/* 2. 체스판 테두리(체스판 최좌측)에 (1234567) 인덱스 출력 */
			if (j == 0)
			{
				SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_INTENSITY);
				std::cout << 8 - i << " ";
			}
			/* 3. 체스판에서 말,빈칸 출력 */
			else
			{
				pPiece = pBoard->GetPiece(j-1, i);
				/* 색깔정하기 */
				if (pPiece && pPiece->player == Piece::Black)
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_BLUE | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
				else
					SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY);
				/* 말출력(함수호출) */
				std::cout << PrintPiece(pPiece);
			}
		}
		std::cout << std::endl;
	}
	return;
}


/**
* @brief	체스판 위에 놓아질 말 출력
* @detail	각 말의 종류에 따라 적절한 문자열로 출력, 말이 아닌 경우 빈칸 출력
* @param	pPiece : 문자형태로 출력하고자 하는 특정 말
*/
char* ChessGraphics::PrintPiece(const Piece* pPiece)
{
	if (pPiece == 0)
		return (char*)"  ";
	else
	{
		switch (pPiece->pieceType)
		{
		case Piece::King:
			return (char*)"Ki";
		case Piece::Queen:
			return (char*)"Qu";
		case Piece::Bishop:
			return (char*)"Bi";
		case Piece::Knight:
			return (char*)"Kn";
		case Piece::Rook:
			return (char*)"Ro";
		case Piece::Pawn:
			return (char*)"Pa";
		default:
			return 0;
		}
	}
	return 0;
}
